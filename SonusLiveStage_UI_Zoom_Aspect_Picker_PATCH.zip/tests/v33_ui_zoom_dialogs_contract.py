"""Static contract for native dialogs / aspect / non-DSP UI preference."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
text = lambda p: (root / p).read_text(encoding='utf-8')

assert 'uiZoom: number' in text('webui/src/store/uiPrefs.ts')
assert 'localStorage.setItem(KEY' in text('webui/src/store/uiPrefs.ts')
assert 'applyUiZoom' in text('webui/src/views/settings/SettingsView.tsx')
assert 'UI_ZOOM_OPTIONS' in text('webui/src/views/settings/SettingsView.tsx')
assert 'style.zoom' in text('webui/src/store/uiZoom.ts')
assert '160vh' in text('webui/src/styles/viewport-guard.css')
assert '62.5vw' in text('webui/src/styles/viewport-guard.css')
assert 'chooseSamplePath' in text('webui/src/views/library/LibraryView.tsx')
assert 'SetOptions(options | FOS_FORCEFILESYSTEM' in text('src/app/NativeWindow.cpp')
assert 'WM_SIZING' in text('src/app/NativeWindow.cpp')
assert 'stageMacSelectSamplePath' in text('src/app/NativeFileDialogMac.mm')
assert 'contentAspectRatio' in text('src/app/NativeFileDialogMac.mm')
assert 'NativeFileDialogMac.mm' in text('CMakeLists.txt')
print('PASS: zoom, aspect and picker integration source contracts')
