cmake_minimum_required(VERSION 3.16)
project(NordVirtualStage VERSION 5.1 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

include(FetchContent)

# Evitar colisión del target "uninstall" entre RtAudio y RtMidi y activar ASIO/WASAPI
set(RTAUDIO_BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(RTAUDIO_BUILD_TESTING OFF CACHE BOOL "" FORCE)
set(RTAUDIO_TARGETNAME_UNINSTALL "uninstall_rtaudio" CACHE STRING "" FORCE)
if(WIN32)
    set(RTAUDIO_API_WASAPI ON CACHE BOOL "" FORCE)
    set(RTAUDIO_API_ASIO ON CACHE BOOL "" FORCE)
endif()

FetchContent_Declare(
    rtaudio
    GIT_REPOSITORY https://github.com/thestk/rtaudio.git
    GIT_TAG 6.0.1
)

set(RTMIDI_BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(RTMIDI_BUILD_TESTING OFF CACHE BOOL "" FORCE)
set(RTMIDI_TARGETNAME_UNINSTALL "uninstall_rtmidi" CACHE STRING "" FORCE)

FetchContent_Declare(
    rtmidi
    GIT_REPOSITORY https://github.com/thestk/rtmidi.git
    GIT_TAG 6.0.0
)

FetchContent_Declare(
    json
    GIT_REPOSITORY https://github.com/nlohmann/json.git
    GIT_TAG v3.11.3
)

FetchContent_MakeAvailable(rtaudio rtmidi json)

add_executable(NordVirtualStage
    src/main.cpp
    src/core/WorkstationHost.cpp
    src/loaders/BankLoader.cpp
    src/loaders/NsmpLoader.cpp
    src/modules/NordPianoEngine.cpp
    src/modules/NordSynthModule.cpp
    src/modules/NordOrganModule.cpp
    src/control/MidiOscMapper.cpp
)

target_include_directories(NordVirtualStage PRIVATE
    src
    src/core
    src/loaders
    src/modules
    src/dsp
    src/control
    third_party
    ${rtaudio_SOURCE_DIR}
    ${rtaudio_SOURCE_DIR}/include
    ${rtmidi_SOURCE_DIR}
)

if(WIN32)
    target_compile_definitions(NordVirtualStage PRIVATE
        _WIN32_WINNT=0x0A00
        __WINDOWS_WASAPI__
        __WINDOWS_ASIO__
        __WINDOWS_MM__
    )
    target_link_libraries(NordVirtualStage PRIVATE
        rtaudio
        rtmidi
        nlohmann_json::nlohmann_json
        winmm
        ole32
        ksuser
        mfplat
        mfuuid
        wmcodecdspuuid
        ws2_32
    )
elseif(APPLE)
    target_compile_definitions(NordVirtualStage PRIVATE __MACOSX_CORE__)
    target_link_libraries(NordVirtualStage PRIVATE
        rtaudio
        rtmidi
        nlohmann_json::nlohmann_json
        "-framework CoreAudio"
        "-framework CoreMIDI"
        "-framework CoreFoundation"
        "-framework AudioToolbox"
    )
elseif(UNIX)
    # Linux (sin probar): RtAudio/RtMidi vía ALSA
    find_package(Threads REQUIRED)
    find_package(ALSA REQUIRED)
    target_compile_definitions(NordVirtualStage PRIVATE __LINUX_ALSA__)
    target_link_libraries(NordVirtualStage PRIVATE
        rtaudio
        rtmidi
        nlohmann_json::nlohmann_json
        ALSA::ALSA
        Threads::Threads
    )
endif()
