// ============================================================================
// ui/js/synth.js — Synth de 3 capas: UI de capas, presets 1-8 y mini-tarjeta de la página MAIN
// El motor C++ soporta 8 presets (NordSynthModule::loadBuiltInSynthPreset) y
// 7 formas de onda (0 SAW … 6 WAVETABLE) y 3 tipos de filtro (LP/HP/BP).
// ============================================================================

const SYNTH_WAVE_LABELS   = ['SAW', 'SQUARE', 'TRIANGLE', 'SINE', 'SUPERSAW', 'NOISE', 'WAVETABLE'];
const SYNTH_FILTER_LABELS = ['LP', 'HP', 'BP'];
const SYNTH_PRESET_COUNT  = 8;

function buildSynthPresetButtons() {
  const box = $('synthPresetButtons');
  if (!box) return;
  box.innerHTML = '';
  for (let id = 1; id <= SYNTH_PRESET_COUNT; id++) {
    const b = document.createElement('button');
    b.className = 'mini-mode-pill' + (id === state.synthPresetId ? ' active' : '');
    b.id = `synthPreBtn_${id}`;
    b.innerText = SYNTH_PRESET_NAMES[id].replace(/^P(\d):/, '$1.');
    b.onclick = () => selectSynthPreset(id);
    box.appendChild(b);
  }
}

function buildSynth3LayersPage() {
  const box = $('synth3LayersContainer');
  if (!box) return;
  box.innerHTML = '';

  for (let i = 1; i <= 3; i++) {
    // Los valores iniciales salen de `state` (definidos en core.js); no se pisan aquí.
    const wavePills = SYNTH_WAVE_LABELS.map((w, idx) =>
      `<span class="mini-mode-pill ${state[`L${i}_wave`] === idx ? 'active' : ''}" id="wavePill_${i}_${idx}" onclick="setLayerWave(${i}, ${idx})">${w}</span>`
    ).join('');
    const filtPills = SYNTH_FILTER_LABELS.map((f, idx) =>
      `<span class="mini-mode-pill ${state[`L${i}_filtType`] === idx ? 'active' : ''}" id="filtTypePill_${i}_${idx}" onclick="setLayerFilterType(${i}, ${idx})">${f}</span>`
    ).join('');
    const knob = (sub, min, max, unit, label, log = 0) =>
      `<div class="knob-cell" data-id="L${i}_${sub}" data-min="${min}" data-max="${max}" data-val="${state[`L${i}_${sub}`]}" data-log="${log}" data-unit="${unit}" data-label="${label}" data-small="1"></div>`;

    const card = document.createElement('div');
    card.className = 'fx-module-black';
    card.style.gap = '10px';
    card.innerHTML = `
      <div class="mod-pill-header red-pill">
        <button class="mod-led-btn ${state[`L${i}_en`] ? 'on' : ''}" id="led_L${i}" onclick="toggleSynthLayer(${i - 1})"></button>
        <span>SYNTH LAYER ${i}</span>
        <span>POLY VA</span>
      </div>
      <div class="mode-pills-row">${wavePills}</div>
      <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:6px; width:100%;">
        ${knob('vol', 0, 1.5, '%', 'LEVEL')}${knob('pan', -1, 1, 'Pan', 'PAN')}
        ${knob('oct', -2, 2, 'oct', 'OCTAVE')}${knob('det', -50, 50, 'ct', 'DETUNE')}
      </div>
      <div class="mode-pills-row">${filtPills}</div>
      <div style="display:grid; grid-template-columns:repeat(2,1fr); gap:6px; width:100%; background:#14171c; padding:6px; border-radius:6px;">
        ${knob('cut', 40, 20000, 'Hz', 'CUTOFF', 1)}${knob('res', 0.5, 12, 'Q', 'RESON')}
      </div>
      <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:6px; width:100%;">
        ${knob('atk', 0.001, 4, 's', 'ATTACK', 1)}${knob('dec', 0.02, 6, 's', 'DECAY', 1)}
        ${knob('sus', 0, 1, '%', 'SUSTAIN')}${knob('rel', 0.02, 6, 's', 'RELEASE', 1)}
      </div>`;
    box.appendChild(card);
  }
}

function setLayerWave(layerNum, waveIdx, silent = false) {
  state[`L${layerNum}_wave`] = waveIdx;
  SYNTH_WAVE_LABELS.forEach((_, w) => setActive(`wavePill_${layerNum}_${w}`, w === waveIdx));
  if (!silent) sendParam(`L${layerNum}_wave`, waveIdx);
}

function setLayerFilterType(layerNum, ftIdx, silent = false) {
  state[`L${layerNum}_filtType`] = ftIdx;
  SYNTH_FILTER_LABELS.forEach((_, f) => setActive(`filtTypePill_${layerNum}_${f}`, f === ftIdx));
  if (!silent) sendParam(`L${layerNum}_filtType`, ftIdx);
}

function toggleSynthLayer(zeroIdx) {
  const i = zeroIdx + 1;
  state[`L${i}_en`] = !state[`L${i}_en`];
  updateSynthLayerBadges(i, state[`L${i}_en`]);
  sendParam(`L${i}_en`, state[`L${i}_en`] ? 1 : 0);
}

function updateSynthLayerBadges(layerNum, enabled) {
  const led = $(`led_L${layerNum}`);
  if (led) led.classList.toggle('on', !!enabled);
  const pill = $(`mainPill_L${layerNum}`);
  if (pill) {
    pill.classList.toggle('active', !!enabled);
    pill.innerText = `L${layerNum} ${enabled ? 'ON' : 'OFF'}`;
  }
}

function stepSynthPreset(dir) {
  const cur = state.synthPresetId || 1;
  selectSynthPreset(((cur - 1 + dir + SYNTH_PRESET_COUNT) % SYNTH_PRESET_COUNT) + 1);
}

// Actualiza solo la UI del preset activo (sin enviar nada a C++)
function showSynthPreset(id) {
  state.synthPresetId = id;
  setText('synthPresetNameMain', SYNTH_PRESET_NAMES[id] || `Preset ${id}`);
  for (let p = 1; p <= SYNTH_PRESET_COUNT; p++) setActive(`synthPreBtn_${p}`, p === id);
}

function selectSynthPreset(id) {
  showSynthPreset(id);
  if (!state.synthEnabled) {
    state.synthEnabled = true;
    sendParam('synthEnabled', 1);
    updateModLeds();
  }
  sendParam('synthPresetId', id);   // C++ devuelve los parámetros del preset y sendParam sincroniza la UI
}
